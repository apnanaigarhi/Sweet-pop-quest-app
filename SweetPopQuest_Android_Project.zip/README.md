# Sweet Pop Quest - Android

Original match-3 candy puzzle game packaged as a native Android WebView app.

## Build APK with GitHub (no PC required)

1. Create a new GitHub repository.
2. Upload ALL files and folders from this project, including `.github`.
3. Keep the default branch as `main` (or `master`).
4. Open the repository's **Actions** tab.
5. Open **Build Android APK**.
6. Tap **Run workflow** if a build did not start automatically.
7. When the build finishes, open the build and download the
   **SweetPopQuest-APK** artifact.
8. Extract the ZIP. Inside it you will find `app-debug.apk`.
9. Install that APK on an Android phone for testing.

## Google Play

This project targets Android 16 / API 36.
For Play Store publishing, build a signed release App Bundle (AAB)
with your own keystore and signing configuration.

## Game file

The actual game is here:

`app/src/main/assets/index.html`

Edit that file to change levels, score, design, candies, sounds, etc.

## App package

`com.sweetpop.quest`

Change `applicationId` and `namespace` before publishing if you want a
different permanent package ID.
